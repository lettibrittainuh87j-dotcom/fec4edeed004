# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(haiku-build src/haiku-build.cpp)
set_property(TARGET haiku-build PROPERTY CXX_STANDARD 11)
target_link_libraries(haiku-build lionss pthread)

add_executable(unity-build src/unity-build.cpp)
set_property(TARGET unity-build PROPERTY CXX_STANDARD 11)
target_link_libraries(unity-build lionss pthread)

add_executable(ccache-stats src/ccache-stats.cpp)
set_property(TARGET ccache-stats PROPERTY CXX_STANDARD 11)
target_link_libraries(ccache-stats lionss pthread)

add_executable(macrobench src/macrobench.cpp)
set_property(TARGET macrobench PROPERTY CXX_STANDARD 11)
target_link_libraries(macrobench lionss pthread)

add_executable(package-pkg src/package-pkg.cpp)
set_property(TARGET package-pkg PROPERTY CXX_STANDARD 11)
target_link_libraries(package-pkg lionss pthread)

add_executable(macos-arm64 src/macos-arm64.cpp)
set_property(TARGET macos-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(macos-arm64 lionss pthread)

add_executable(license-audit src/license-audit.cpp)
set_property(TARGET license-audit PROPERTY CXX_STANDARD 11)
target_link_libraries(license-audit lionss pthread)

add_executable(parser-fuzz src/parser-fuzz.cpp)
set_property(TARGET parser-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(parser-fuzz lionss pthread)

add_executable(gcc-trunk src/gcc-trunk.cpp)
set_property(TARGET gcc-trunk PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-trunk lionss pthread)

add_executable(chocolatey-package src/chocolatey-package.cpp)
set_property(TARGET chocolatey-package PROPERTY CXX_STANDARD 11)
target_link_libraries(chocolatey-package lionss pthread)

add_executable(hot-path-profile src/hot-path-profile.cpp)
set_property(TARGET hot-path-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(hot-path-profile lionss pthread)

add_executable(ninja-build src/ninja-build.cpp)
set_property(TARGET ninja-build PROPERTY CXX_STANDARD 11)
target_link_libraries(ninja-build lionss pthread)

add_executable(sdist-build src/sdist-build.cpp)
set_property(TARGET sdist-build PROPERTY CXX_STANDARD 11)
target_link_libraries(sdist-build lionss pthread)

add_executable(atomics-bench src/atomics-bench.cpp)
set_property(TARGET atomics-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(atomics-bench lionss pthread)

add_executable(binary-size src/binary-size.cpp)
set_property(TARGET binary-size PROPERTY CXX_STANDARD 11)
target_link_libraries(binary-size lionss pthread)

add_executable(vcpkg-port src/vcpkg-port.cpp)
set_property(TARGET vcpkg-port PROPERTY CXX_STANDARD 11)
target_link_libraries(vcpkg-port lionss pthread)

add_executable(callgrind-profile src/callgrind-profile.cpp)
set_property(TARGET callgrind-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(callgrind-profile lionss pthread)

add_executable(coverity-scan src/coverity-scan.cpp)
set_property(TARGET coverity-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(coverity-scan lionss pthread)

add_executable(linux-riscv64 src/linux-riscv64.cpp)
set_property(TARGET linux-riscv64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-riscv64 lionss pthread)

add_executable(find-package-check src/find-package-check.cpp)
set_property(TARGET find-package-check PROPERTY CXX_STANDARD 11)
target_link_libraries(find-package-check lionss pthread)

add_executable(cosign-verify src/cosign-verify.cpp)
set_property(TARGET cosign-verify PROPERTY CXX_STANDARD 11)
target_link_libraries(cosign-verify lionss pthread)

add_executable(seed-corpus src/seed-corpus.cpp)
set_property(TARGET seed-corpus PROPERTY CXX_STANDARD 11)
target_link_libraries(seed-corpus lionss pthread)

add_executable(golden-tests src/golden-tests.cpp)
set_property(TARGET golden-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(golden-tests lionss pthread)

add_executable(flamegraph src/flamegraph.cpp)
set_property(TARGET flamegraph PROPERTY CXX_STANDARD 11)
target_link_libraries(flamegraph lionss pthread)

add_executable(simd-throughput src/simd-throughput.cpp)
set_property(TARGET simd-throughput PROPERTY CXX_STANDARD 11)
target_link_libraries(simd-throughput lionss pthread)

add_executable(maximal-versions src/maximal-versions.cpp)
set_property(TARGET maximal-versions PROPERTY CXX_STANDARD 11)
target_link_libraries(maximal-versions lionss pthread)

add_executable(reuse-lint src/reuse-lint.cpp)
set_property(TARGET reuse-lint PROPERTY CXX_STANDARD 11)
target_link_libraries(reuse-lint lionss pthread)

add_executable(vendored-check src/vendored-check.cpp)
set_property(TARGET vendored-check PROPERTY CXX_STANDARD 11)
target_link_libraries(vendored-check lionss pthread)

add_executable(markdown-lint src/markdown-lint.cpp)
set_property(TARGET markdown-lint PROPERTY CXX_STANDARD 11)
target_link_libraries(markdown-lint lionss pthread)

add_executable(msan src/msan.cpp)
set_property(TARGET msan PROPERTY CXX_STANDARD 11)
target_link_libraries(msan lionss pthread)

