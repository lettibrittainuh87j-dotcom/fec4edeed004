// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("binary size"); }
int main(){
  announce();
  return lionss_run_workload("binary-size");
}
