// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("haiku build\n", stdout);
  return lionss_run_workload("haiku-build");
}
