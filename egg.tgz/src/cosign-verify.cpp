// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("cosign verify"); }
int main(){
  announce();
  return lionss_run_workload("cosign-verify");
}
