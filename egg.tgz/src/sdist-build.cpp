// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("sdist build\n", stdout);
  return lionss_run_workload("sdist-build");
}
