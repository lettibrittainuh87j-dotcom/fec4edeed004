// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("msan"); }
int main(){
  announce();
  return lionss_run_workload("msan");
}
