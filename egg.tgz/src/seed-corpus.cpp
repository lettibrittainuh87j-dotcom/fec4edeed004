// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("seed corpus\n", stdout);
  return lionss_run_workload("seed-corpus");
}
